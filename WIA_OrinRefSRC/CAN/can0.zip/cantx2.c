#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <net/if.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/can.h>
#include <linux/can/raw.h>

int main() {
    int s;
    struct sockaddr_can addr;
    struct canfd_frame frame;
    struct ifreq ifr;

    // Create socket
    s = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    if (s < 0) {
        perror("Socket");
        return 1;
    }

    strcpy(ifr.ifr_name, "can0");
    ioctl(s, SIOCGIFINDEX, &ifr);

    memset(&addr, 0, sizeof(addr));
    addr.can_family = AF_CAN;
    addr.can_ifindex = ifr.ifr_ifindex;

    // Enable CAN FD support
    setsockopt(s, SOL_CAN_RAW, CAN_RAW_FD_FRAMES, &ifr, sizeof(ifr));

    if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("Bind");
        return 1;
    }

    // Prepare CAN FD frame
    frame.can_id = 0x123 | CAN_EFF_FLAG;
    frame.len = 8; // CAN FD frames can be up to 64 bytes
    frame.flags = 0; // Flags for FD frames, e.g., BRS
    strcpy((char *)frame.data, "CAN-FD");

    // Send frame
    if (write(s, &frame, sizeof(frame)) != sizeof(frame)) {
        perror("Write");
        return 1;
    }

    close(s);
    return 0;
}
